package com.jer.githubappsederhana.ui.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.jer.githubappsederhana.databinding.ActivityMainBinding
import com.jer.githubappsederhana.response.ItemsItem

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
//    private lateinit var mainViewModel2: MainViewModel
//    private lateinit var userAdapter: UserAdapter
//    private val githubApiService = RetrofitClient.createService(ApiService::class.java)

    companion object {
        private const val TAG = "MainActivity"
        private const val USER = "fajar"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()


        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        mainViewModel.listUser.observe(this) { userGithub ->
            setUserData(userGithub)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }


        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    searchBar.text = searchView.text
                    searchView.hide()
                    Toast.makeText(this@MainActivity, searchView.text, Toast.LENGTH_SHORT).show()
                    false
                }
            searchView
                .editText
                .addTextChangedListener { editable ->
                    val query = editable.toString()
                    mainViewModel.setSearchQuery(query)
                }

        }





        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.recyclerView.addItemDecoration(itemDecoration)













        // Inisialisasi SearchView
//        val searchView = findViewById<SearchView>(R.id.searchView)
//        val searchView = binding.searchView
//
//        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
//            override fun onQueryTextSubmit(query: String?): Boolean {
//                // Panggil fungsi pencarian saat pengguna menekan tombol cari
//                if (!query.isNullOrBlank()) {
//                    searchGithubUsers(query)
//                }
//                return true
//            }
//
//            override fun onQueryTextChange(newText: String?): Boolean {
//                // Tindakan saat teks pencarian berubah (optional)
//                return true
//            }
//        })
//
//
//
//
//        binding = ActivityMainBinding.inflate(layoutInflater)
//        val view = binding.root
//        setContentView(view)
//        val recyclerViewUsers = binding.recyclerViewUsers
//        // Konfigurasi RecyclerView
//        userAdapter = UserAdapter(emptyList()) { selectedUser ->
//            // Handle item click event (pindah ke halaman detail, dll.)
//        }
//
//        binding.recyclerViewUsers.layoutManager = LinearLayoutManager(this)
//        binding.recyclerViewUsers.adapter = userAdapter
//
//        // Mengambil data pengguna GitHub dari API menggunakan Retrofit
//        searchGithubUsers("YOUR_SEARCH_KEYWORD")
    }




    private fun setUserData(userGithub: List<ItemsItem>) {
        val adapter = UserAdapter(this)
        adapter.submitList(userGithub)
        binding.recyclerView.adapter = adapter
//        binding.searchView.setText("")

    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }





//    private fun searchGithubUsers(query: String) {
//        val call = githubApiService.searchUsers(query)
//        call.enqueue(object : Callback<SearchUserResponse> {
//            override fun onResponse(
//                call: Call<SearchUserResponse>,
//                response: Response<SearchUserResponse>
//            ) {
//                if (response.isSuccessful) {
//                    val users = response.body()?.items ?: emptyList()
//                    updateRecyclerView(users)
//                } else {
//                    // Handle error response from API
//                }
//            }
//
//            override fun onFailure(call: Call<SearchUserResponse>, t: Throwable) {
//                // Handle network errors
//            }
//        })
//    }
//
//    private fun updateRecyclerView(users: List<ItemsItem>) {
//        userAdapter = UserAdapter(users) { selectedUser ->
//            // Handle item click event (pindah ke halaman detail, dll.)
//        }
//        binding.recyclerViewUsers.adapter = userAdapter
//    }
}